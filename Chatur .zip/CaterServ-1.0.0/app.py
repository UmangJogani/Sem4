from flask import Flask, render_template, request, redirect, url_for, jsonify,send_file,flash,session,send_from_directory
from flask_sqlalchemy import SQLAlchemy
import requests
from sqlalchemy.exc import IntegrityError
import os
import random

# Initialize Flask app
app = Flask(__name__, static_folder='static')

# Configure SQLAlchemy
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:@localhost/cmp1'

db = SQLAlchemy(app)




class Signin(db.Model):
    id = db.Column(db.Integer , primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    father_name = db.Column(db.String(150), nullable=False)
    age = db.Column(db.String(15), nullable=False)
    Gender = db.Column(db.String(15), nullable=False)
    address = db.Column(db.String(300), nullable=False)
    city = db.Column(db.String(150), nullable=False)
    country = db.Column(db.String(150), nullable=False)
    contact = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(150), nullable=False)
    password = db.Column(db.String(150), nullable=False)
    c_password = db.Column(db.String(150), nullable=False)
    adhar_card = db.Column(db.String(150), nullable=False)
    gotra = db.Column(db.String(150), nullable=False)
    cast = db.Column(db.String(150), nullable=False)
    occupation = db.Column(db.String(150), nullable=False)
    life_membership_fees = db.Column(db.String(150), nullable=False)
    subscription = db.Column(db.String(150), nullable=False)
    mode_of_pay = db.Column(db.String(150), nullable=False)
    
    
class News(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(400), nullable=False)
    description = db.Column(db.String(500), nullable=False)
    photo = db.Column(db.String(100),nullable=False)

class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(400), nullable=False)
    description = db.Column(db.String(500), nullable=False)
    photo = db.Column(db.String(100),nullable=False)
    
class Package(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    duration = db.Column(db.String(100), nullable=False)
    features = db.Column(db.String(100), nullable=False)
    price = db.Column(db.String(100), nullable=False)

class Gallery(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    photo = db.Column(db.String(100), nullable=False)
    
@app.route('/', methods=['GET','POST'])
def signin():
    if request.method == 'POST':
        user = Signin(
            name = request.form['name'],
            father_name = request.form['father_name'],
            age = request.form['age'],
            Gender = request.form['gender'],
            address = request.form['address'],
            city = request.form['city'],
            country = request.form['country'],
            contact = request.form['contact'],
            email = request.form['email'],
            password = request.form['password'],
            c_password = request.form['c_password'],
            adhar_card = request.form['a_card'],
            gotra = request.form['gotra'],
            cast = request.form['cast'],
            occupation = request.form['occupation'],
            life_membership_fees = request.form['life'],
            subscription = request.form['sub'],
            mode_of_pay = request.form['pay']
        )
        
        db.session.add(user)
        db.session.commit()
        
        return redirect(url_for('index'))

    return render_template('signin.html')


@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/gallery')
def gallery():
    return  render_template('gallery.html')

@app.route('/package')
def package():
    return render_template('package.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/latestnews')
def latestnews():
    return render_template('latestnews.html')






if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    #app.debug = True
    app.run(debug=True, port=4000)