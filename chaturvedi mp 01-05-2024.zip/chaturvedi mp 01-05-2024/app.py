from flask import Flask, render_template, request, redirect, url_for, jsonify,send_file,flash,session,send_from_directory
from flask_sqlalchemy import SQLAlchemy
import requests
from sqlalchemy.exc import IntegrityError
import os
import random
import razorpay

# Initialize Flask app
app = Flask(__name__, static_folder='static')

# Configure SQLAlchemy
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:@localhost/cmp1'

db = SQLAlchemy(app)


class Admin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    contact = db.Column(db.String(10), nullable=False)
    email = db.Column(db.String(20), nullable=False)
    password = db.Column(db.String(20), nullable=False)
    Activation = db.Column(db.String(20),nullable=False)
    create = db.Column(db.Boolean, default=False)
    read = db.Column(db.Boolean, default=False)
    write = db.Column(db.Boolean, default=False)
    delete = db.Column(db.Boolean, default=False)
    sb = db.Column(db.Boolean, default=False)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    address = db.Column(db.String(255), nullable=False)
    area = db.Column(db.String(100), nullable=False)
    city = db.Column(db.String(100), nullable=False)
    state = db.Column(db.String(100), nullable=False)
    contact = db.Column(db.String(20), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    password = db.Column(db.String(100), nullable=False)
    gender = db.Column(db.String(10), nullable=False)
    birth_date = db.Column(db.Date, nullable=False)
    father_name = db.Column(db.String(100), nullable=False)
    mother_name = db.Column(db.String(100), nullable=False)
    brother_name = db.Column(db.String(100), nullable=False)
    sister_name = db.Column(db.String(100), nullable=False)
    grand_father_name = db.Column(db.String(100), nullable=False)
    grand_mother_name = db.Column(db.String(100), nullable=False)
    great_grandfather_name = db.Column(db.String(100), nullable=False)
    gotra = db.Column(db.String(100), nullable=False)
    cast = db.Column(db.String(100), nullable=False)
    subcast = db.Column(db.String(100), nullable=False)
    marital_status = db.Column(db.String(20), nullable=False)
    children = db.Column(db.String(20), nullable=False)
    house = db.Column(db.String(100), nullable=False)
    job = db.Column(db.String(100), nullable=False)
    occupation = db.Column(db.String(100), nullable=False)
    interests = db.Column(db.String(255), nullable=False)
    activation = db.Column(db.String(10), nullable=False)

class Signin(db.Model):
    sign_id = db.Column(db.Integer , primary_key=True)
    payment_id = db.Column(db.String(100), nullable=True)
    name = db.Column(db.String(200), nullable=False)
    father_name = db.Column(db.String(150), nullable=False)
    age = db.Column(db.String(15), nullable=False)
    Gender = db.Column(db.String(15), nullable=False)
    address = db.Column(db.String(300), nullable=False)
    area = db.Column(db.String(300), nullable=False)
    city = db.Column(db.String(150), nullable=False)
    state = db.Column(db.String(150), nullable=False)
    country = db.Column(db.String(150), nullable=False)
    contact = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(150), nullable=False)
    password = db.Column(db.String(150), nullable=False)
    c_password = db.Column(db.String(150), nullable=False)
    adhar_card = db.Column(db.String(150), nullable=False)
    gotra = db.Column(db.String(150), nullable=False)
    cast = db.Column(db.String(150), nullable=False)
    date = db.Column(db.String(20),nullable=False)
    occupation = db.Column(db.String(150), nullable=False)
    life_membership_fees = db.Column(db.String(150), nullable=False)
    subscription = db.Column(db.String(150), nullable=False)
    mode_of_pay = db.Column(db.String(150), nullable=False)
    Activation = db.Column(db.String(20),default='Active')
    

    
    
class News(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(400), nullable=False)
    description = db.Column(db.String(500), nullable=False)
    photo = db.Column(db.String(100),nullable=False)
    date = db.Column(db.String(20),nullable=False)


class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(400), nullable=False)
    description = db.Column(db.String(500), nullable=False)
    photo = db.Column(db.String(100),nullable=False)
    date = db.Column(db.String(20),nullable=False)

    
class Package(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    duration = db.Column(db.String(100), nullable=False)
    features = db.Column(db.String(100), nullable=False)
    price = db.Column(db.String(100), nullable=False)



class Gallery(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    photo = db.Column(db.String(100), nullable=False)
    Activation = db.Column(db.String(20),nullable=False)

    
class Contact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    address = db.Column(db.String(255), nullable=False)



def save_file(file):
    if file:
        file_path = f"static/{file.filename}"
        file.save(file_path)
        return file_path
    return None



########################################## User ###########################################

@app.route('/', methods=['GET', 'POST'])
def signin():
    if request.method == 'POST':
        payment_id = request.form.get('payment_id')
        if payment_id:
            # Payment successful, proceed with user registration
            user = Signin(
                name=request.form['name'],
                father_name=request.form['father_name'],
                age=request.form['age'],
                Gender=request.form['gender'],
                address=request.form['address'],
                area=request.form['area'],
                city=request.form['city'],
                state=request.form['state'],
                country=request.form['country'],
                contact=request.form['contact'],
                email=request.form['email'],
                password=request.form['password'],
                c_password=request.form['c_password'],
                adhar_card=request.form['a_card'],
                gotra=request.form['gotra'],
                cast=request.form['cast'],
                occupation=request.form['occupation'],
                date=request.form['date'],
                life_membership_fees=request.form['life'],
                subscription=request.form['sub'],
                mode_of_pay=request.form['pay'],
                payment_id=payment_id  # Store the payment ID in the database
            )

            db.session.add(user)
            db.session.commit()

            # Redirect to the home page
            return redirect(url_for('card'))
        else:
            # Payment failed or user canceled the payment, handle accordingly
            return "Payment failed or canceled. Please try again."
    
    # Render the sign-in form for GET requests
    return render_template('signin.html')


@app.route('/index/<int:sign_id>')
def index(sign_id):
    news = News.query.all()
    event = Event.query.all()
    gallery = Gallery.query.all()
    package = Package.query.all()
    signin = Signin.query.get(sign_id)
    return render_template('index.html',news=news,event=event,gallery=gallery,package=package,signin=signin)

@app.route('/user_login',methods=['GET','POST'])
def user_login():
    signin = Signin.query.all()
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        signin = Signin.query.filter_by(email=email, password=password,Activation='Active').first()
        if signin:
            return redirect(url_for('index', sign_id = signin.sign_id))
        
    return render_template('user_login.html',signin=signin)


@app.route('/card')
def card():
    return render_template('card.html')

@app.route('/latestnews/<int:sign_id>')
def latestnews(sign_id):
    news = News.query.all()
    signin = Signin.query.get(sign_id)
    return render_template('latestnews.html',news=news,signin=signin)

@app.route('/contact/<int:sign_id>', methods=['GET','POST'])
def contact(sign_id):
    signin = Signin.query.get(sign_id)
    if request.method == 'POST':
        user = Contact(
            name = request.form['name'],
            email = request.form['email'],
            address = request.form['address']
        )
        
        db.session.add(user)
        db.session.commit()
        
        return redirect(url_for('contact'))
    return render_template('contact.html',signin=signin)

@app.route('/package/<int:sign_id>')
def package(sign_id):
    package = Package.query.all()
    signin = Signin.query.get(sign_id)
    return render_template('package.html',package=package,signin=signin)



@app.route('/about/<int:sign_id>')
def about(sign_id):
    signin = Signin.query.get(sign_id)
    return render_template('about.html',signin=signin)

@app.route('/gallery/<int:sign_id>')
def gallery(sign_id):
    gallery = Gallery.query.all()
    signin = Signin.query.get(sign_id)
    return  render_template('gallery.html',gallery=gallery,signin=signin)






########################################## admin ##########################################





@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Retrieve email and password from the form
        email = request.form['email']
        password = request.form['password']

        # Query the User table to check login credentials
        user = Admin.query.filter_by(email=email, password=password,Activation='Active').first()
        
        if user:
            # Pass the admin ID to the home page route
            return redirect(url_for('ad_index', id=user.id))
        else:
            # Invalid email or password
            error_message = "Invalid email or password. Please try again."
            return render_template('admin/login.html', error=error_message)
    
    # If it's a GET request, render the login page
    return render_template('admin/login.html')


@app.route('/ad_index/<int:id>')
def ad_index(id):
    admin = Admin.query.get_or_404(id)
    total_users = User.query.count()
    return render_template('admin/ad_index.html', admin=admin,total_users=total_users)


@app.route('/add_sub_admin/<int:id>', methods=['GET', 'POST'])
def add_sub_admin(id):
    admin = Admin.query.get(id)
    if request.method == 'POST':
        admin = Admin(
            name = request.form['name'],
            contact = request.form['contact'],
            email = request.form['email'],
            password = request.form['password'],
            Activation = request.form['activation'],
            create='create' in request.form,
            read='read' in request.form,
            write='write' in request.form
        )

        db.session.add(admin)
        db.session.commit()

        return redirect(url_for('view_sub_admin',id=id))
    return render_template('admin/add_sub_admin.html',admin=admin)


@app.route('/edit_sub_admin/<int:id>/<int:sb_id>', methods=['GET', 'POST'])
def edit_sub_admin(id,sb_id):
    admin = Admin.query.get(id)
    admins = Admin.query.get(sb_id)

    if request.method == 'POST':
        updated_name = request.form['name']
        updated_contact = request.form['contact']
        updated_email = request.form['email']
        updated_password = request.form['password']
        update_activation = request.form['activation']
        update_create='create' in request.form
        update_read='read' in request.form
        update_write='write' in request.form


        # Print the updated data to see if it's received correctly
        print(updated_name, updated_contact, updated_email, updated_password,update_activation,update_create,update_read,update_write)

        # Update the admin object with the new data
        admins.name = updated_name
        admins.contact = updated_contact
        admins.email = updated_email
        admins.password = updated_password
        admins.Activation = update_activation
        admins.create = update_create
        admins.read = update_read
        admins.write = update_write

        # Print the admin object before and after the update
        print("Admin before commit:", admin)

        # Commit the changes to the database
        db.session.commit()

        # Print the admin object after the update
        print("Admin after commit:", admin)

        return redirect(url_for('view_sub_admin', id=admin.id))
    
    return render_template('admin/edit_sub_admin.html', admin=admin,admins=admins)

@app.route('/view_sub_admin/<int:id>')
def view_sub_admin(id):
    admins = Admin.query.get_or_404(id)
    admin = Admin.query.all()
    return render_template('admin/view_sub_admin.html',admin=admin,admins=admins)

@app.route('/add_user/<int:id>', methods=['GET', 'POST'])
def add_user(id):
    admin = Admin.query.get(id)
    if request.method == 'POST':
        payment_id = request.form.get('payment_id')
        if payment_id:
        # Get form data
            signin = Signin(
                name=request.form['name'],
                father_name=request.form['father_name'],
                age=request.form['age'],
                Gender=request.form['gender'],
                address=request.form['address'],
                area=request.form['area'],
                city=request.form['city'],
                state=request.form['state'],
                country=request.form['country'],
                contact=request.form['contact'],
                email=request.form['email'],
                password=request.form['password'],
                c_password=request.form['c_password'],
                adhar_card=request.form['a_card'],
                gotra=request.form['gotra'],
                cast=request.form['cast'],
                occupation=request.form['occupation'],
                date=request.form['date'],
                life_membership_fees=request.form['life'],
                subscription=request.form['sub'],
                mode_of_pay=request.form['pay'],
                payment_id=payment_id 
            )

            # Add the user to the database
            db.session.add(signin)
            db.session.commit()

            return redirect(url_for('view_user',id=admin.id))
        else:
            # Payment failed or user canceled the payment, handle accordingly
            return "Payment failed or canceled. Please try again."
        
    return render_template('admin/add_user.html',admin=admin)


    

@app.route('/update_activation', methods=['POST'])
def update_activation():
    data = request.get_json()
    sign_id = data.get('sign_id')
    new_status = data.get('new_status')

    # Update the database based on sign_id and new_status
    signin = Signin.query.get(sign_id)
    if signin:
        signin.Activation = new_status
        db.session.commit()
        return jsonify({'success': True}), 200
    else:
        return jsonify({'error': 'User not found'}), 404

    
@app.route('/view_user/<int:id>')
def view_user(id):
    admin = Admin.query.get_or_404(id)
    signin = Signin.query.all()
    return render_template('admin/view_user.html',signin=signin,admin=admin)

@app.route('/add_event/<int:id>', methods=['GET', 'POST'])
def add_event(id):
    admin = Admin.query.get(id)
    if request.method == 'POST':
        event = Event(
            title=request.form['title'],
            description=request.form['description'],
            date=request.form['date'],
            Activation=request.form['Activation']
        )

        # Assuming you have a function named `save_file` to save the photo
        event.photo = save_file(request.files['photo'])
        
        # Add the user to the database
        db.session.add(event)
        db.session.commit()
        
        return redirect(url_for('view_event', id=admin.id))
    return render_template('admin/add_event.html', admin=admin)

@app.route('/view_event/<int:id>')
def view_event(id):
    admin = Admin.query.get_or_404(id)
    event = Event.query.all()
    return render_template('admin/view_event.html',event=event,admin=admin)

@app.route('/add_news/<int:id>', methods=['GET', 'POST'])
def add_news(id):
    admin = Admin.query.get(id)
    if request.method == 'POST':
        news= News(
            title = request.form['title'],
            description = request.form['description'],
            date = request.form['date'],
            Activation = request.form['Activation']
        )

        # Assuming you have a function named `save_file` to save the photo
        news.photo = save_file(request.files['photo'])
        
        # Add the user to the database
        db.session.add(news)
        db.session.commit()

        return redirect(url_for('view_news',id=admin.id))
    return render_template('admin/add_news.html',admin=admin)

@app.route('/view_news/<int:id>')
def view_news(id):
    admin = Admin.query.get_or_404(id)
    news = News.query.all()
    return render_template('admin/view_news.html',news=news,admin=admin)

@app.route('/add_package/<int:id>', methods=['GET', 'POST'])
def add_package(id):
    admin = Admin.query.get(id)
    if request.method == 'POST':
        package = Package(
            name = request.form['name'],
            duration = request.form['duration'],
            features = request.form['features'],
            price = request.form['price']
        )

        # Assuming you have a function named `save_file` to save the photo
        
        # Add the user to the database
        db.session.add(package )
        db.session.commit()

        return redirect(url_for('view_package',id=admin.id))
    return render_template('admin/add_package.html',admin=admin)

@app.route('/view_package/<int:id>')
def view_package(id):
    admin = Admin.query.get_or_404(id)
    package = Package.query.all()
    return render_template('admin/view_package.html',package=package,admin=admin)






if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    #app.debug = True
    app.run(debug=True, port=4000)